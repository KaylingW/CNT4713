"""Name: Kayling Wong 
    PID: 5964595
    Credits: Geeks for geeks; https://www.geeksforgeeks.org/simple-chat-room-using-python/"""

import socket
import select
import sys

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if len(sys.argv) != 3:
    print "How to use: script, IP address, port number"
    exit()
#IP_address: Takes first argument from the cmd
IP_address = str(sys.argv[1])
#Port: Takes second argument from the cmd
Port = int(sys.argv[2])
#Connect to server using the two arguments.
server.connect((IP_address, Port))

while True:
    #Creates socket lists. 
    sockets_list = [sys.stdin, server]
    #User can choose to send a message or server sends a message. Select allows input reading.
    read_sockets,write_socket, error_socket = select.select(sockets_list, [], [])
    for socks in read_sockets:
        #If server wants to send a message, then receive & print message from port 2048.
        if socks == server:
            message = socks.recv(2048)
            print message
        #else: If user wants to send message, read from the cmd line, send message and flush.
        else:
            message = sys.stdin.readline()
            server.send(message)
            sys.stdout.write("[Me]")
            sys.stdout.write(message)
            sys.stdout.flush()
server.close()