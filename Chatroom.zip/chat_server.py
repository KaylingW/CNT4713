"""Name: Kayling Wong 
    PID: 5964595
    Credits: Geeks for geeks; https://www.geeksforgeeks.org/simple-chat-room-using-python/"""

import socket
import select
from thread import *
import sys

"""
Passes two arguments: AF_INET and SOCK_STREAM. AF_INET is the socket's domain address and we use this when we have an internet domain with 2 hosts.
SOCK_STREAM is the flowd of data/characters that are read."""
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Setsockopt: Sets current value for the socket option
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# Check if the amount of arguments does not equal 3. If not, print usage message."""
if len(sys.argv) != 3:
    print "Correct usage: script, IP address, port number"
    exit()


# IP_address takes first argument from the cmd.
IP_address = str(sys.argv[1])
# Port takes second argument from the cmd. These two arguments will be binded.
Port = int(sys.argv[2])
# Bind the server with the IP_address provided at the port number provided. These parameters must be known to the client.
server.bind((IP_address, Port))

# server.listen looks for 150 connections. This will allow us to create new sockets.
server.listen(150)

list_of_clients = []

# method for multithreading. A thread is a sub process that runs a set of commands.
# these individual threads will help us create the chat room.


def clientthread(conn, addr):
    conn.send("Hello! You have entered a chat room. Go ahead and type something.")
    # As long as the client's user object is "conn", send message.
    while True:
            try:
                # receive connection from port 2048
                message = conn.recv(2048)
                if message:
                    # Prints address and user of whose message was just sent through the server.
                    print "[" + addr[0] + "]" + message
                    # message is broadcasted to all connected users.
                    message_to_send = "[" + addr[0] + "] " + message
                    broadcast(message_to_send, conn)

                else:
                    # remove connection if there's no content/broken connection.
                    remove(conn)
            except:
                continue

# Broadcast function. Messages are broadcasted to all clients who have a different object.


def broadcast(message, connection):
    for clients in list_of_clients:
        # if clients do not have same connection, send message.
        if clients != connection:
            try:
                clients.send(message)
            except:
                clients.close()
                # if link is broken, remove clients.
                remove(clients)

# Remove function. Removes objects from the previously created list.


def remove(connection):
    if connection in list_of_clients:
        list_of_clients.remove(connection)

""" While loop that allows connection requests and stores this in conn. Conn is a socket object. This object contains the IP address of the connected client."""
while True:
    conn, addr = server.accept()
    # Client lists: Messages can be broadcasted to all available people in the chat by maintaining this list.
    list_of_clients.append(conn)
    print addr[0] + " connected"
    
    # Thread creation whenever a new user connects.
    start_new_thread(clientthread,(conn,addr))
  

conn.close()
server.close()
